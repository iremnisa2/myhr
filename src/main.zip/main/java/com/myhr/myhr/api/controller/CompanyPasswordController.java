package com.myhr.myhr.api.controller;

import com.myhr.myhr.application.service.CompanyPasswordService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@RequiredArgsConstructor
@RequestMapping("/api/companies")
public class CompanyPasswordController {

    private final CompanyPasswordService companyPasswordService;

    @GetMapping("/set-password")
    @ResponseBody
    public String showSetPasswordForm(@RequestParam String token) {
        return """
                    <!doctype html>
                    <html lang="tr">
                      <head><meta charset="UTF-8"><title>Şifre Belirle</title></head>
                      <body>
                        <h2>Şifre Belirleme</h2>
                        <form method="post" action="/api/companies/set-password"> <!-- POST'u ApprovalController karşılayacak -->
                          <input type="hidden" name="token" value="%s" />
                          <label>Şifre Giriniz:</label><br>
                          <input type="password" name="password" required /><br><br>
                          <button type="submit">Gönder</button>
                        </form>
                      </body>
                    </html>
                """.formatted(token);
    }
}

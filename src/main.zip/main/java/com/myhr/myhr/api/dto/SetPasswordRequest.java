
package com.myhr.myhr.api.dto;

public record SetPasswordRequest(String token, String password) {}

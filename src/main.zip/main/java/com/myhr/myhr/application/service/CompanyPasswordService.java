package com.myhr.myhr.application.service;

import com.myhr.myhr.infrastructure.entity.ApprovalTokenEntity;
import com.myhr.myhr.infrastructure.entity.CompanyEntity;
import com.myhr.myhr.infrastructure.repository.CompanyJpaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.Instant;

@Service
@RequiredArgsConstructor
public class CompanyPasswordService {

    private final CompanyJpaRepository companyRepository;
    private final PasswordEncoder passwordEncoder;

    public void setPassword(String token, String rawPassword) {

        CompanyEntity company = companyRepository.findByApprovalToken(token)
                .orElseThrow(() -> new IllegalArgumentException("Token geçersiz"));


        Instant expiresAt = company.getApprovalTokenExpiresAt();
        if (expiresAt == null || expiresAt.isBefore(Instant.now())) {
            throw new IllegalStateException("Token süresi dolmuş");
        }


        company.setPasswordHash(passwordEncoder.encode(rawPassword));


        company.setApprovalToken(null);
        company.setApprovalTokenExpiresAt(null);

        companyRepository.save(company);
    }
}


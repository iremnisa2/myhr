package com.myhr.myhr.application.service;

import com.myhr.myhr.domain.CompanyStatus;
import com.myhr.myhr.domain.exception.ApiException;
import com.myhr.myhr.domain.exception.ErrorCode;
import com.myhr.myhr.infrastructure.entity.ApprovalTokenEntity;
import com.myhr.myhr.infrastructure.entity.CompanyEntity;
import com.myhr.myhr.infrastructure.repository.ApprovalTokenJpaRepository;
import com.myhr.myhr.infrastructure.repository.CompanyJpaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.security.SecureRandom;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.HexFormat;

@Service
@RequiredArgsConstructor
public class CompanyApprovalService {

    private final ApprovalTokenJpaRepository approvalRepo;
    private final CompanyJpaRepository companyRepo;
    private final PasswordEncoder passwordEncoder;
    private final MailService mailService;


    public String approveAndCreateToken(Long companyId) {
        CompanyEntity company = companyRepo.findById(companyId)
                .orElseThrow(() -> new ApiException(ErrorCode.COMPANY_NOT_FOUND));

        String token = generateToken();
        Instant expiresAt = Instant.now().plus(24, ChronoUnit.HOURS);

        ApprovalTokenEntity approval = ApprovalTokenEntity.builder()
                .token(token)
                .expiresAt(expiresAt)
                .company(company)
                .build();

        approvalRepo.save(approval);
        mailService.sendSetPassword(company.getEmail(), token);
        return token;
    }


    public void setPasswordWithToken(String token, String rawPassword) {
        var approval = approvalRepo.findByToken(token.trim())
                .orElseThrow(() -> new ApiException(ErrorCode.TOKEN_NOT_FOUND));

        if (approval.isUsed()) throw new ApiException(ErrorCode.TOKEN_USED);
        if (approval.getExpiresAt().isBefore(Instant.now())) throw new ApiException(ErrorCode.TOKEN_EXPIRED);
        if (rawPassword == null || rawPassword.length() < 8) throw new ApiException(ErrorCode.PASSWORD_TOO_WEAK);

        var company = approval.getCompany();
        if (company == null) throw new ApiException(ErrorCode.COMPANY_NOT_FOUND);

        company.setPasswordHash(passwordEncoder.encode(rawPassword));
        company.setStatus(CompanyStatus.ACTIVE);
        companyRepo.save(company);

        approval.setUsed(true);
        approvalRepo.save(approval);

    }

    private String generateToken() {
        byte[] buf = new byte[32];
        new SecureRandom().nextBytes(buf);
        return HexFormat.of().formatHex(buf);
    }
}

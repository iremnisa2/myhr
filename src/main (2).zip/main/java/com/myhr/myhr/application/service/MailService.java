package com.myhr.myhr.application.service;

import lombok.RequiredArgsConstructor;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class MailService {
    private final JavaMailSender mailSender;

    public void sendSetPassword(String to, String token) {
        SimpleMailMessage msg = new SimpleMailMessage();
        msg.setTo(to);
        msg.setSubject("Set your password - MyHR");
        msg.setText("""
                Merhaba,

                Şifreni belirlemek için linke tıklayınız:
                http://localhost:8080/api/companies/set-password?token=%s
                
                Bu link 24 saat geçerlidir.
                """.formatted(token));
        mailSender.send(msg);
    }
}

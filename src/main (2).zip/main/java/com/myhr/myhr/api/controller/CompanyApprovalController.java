package com.myhr.myhr.api.controller;

import com.myhr.myhr.application.service.CompanyApprovalService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/companies")
@RequiredArgsConstructor
public class CompanyApprovalController {

    private final CompanyApprovalService approvalService;


    @PostMapping("/{id}/approve")
    public ResponseEntity<?> approve(@PathVariable Long id) {
        String token = approvalService.approveAndCreateToken(id);


        return ResponseEntity.ok(Map.of(
                "message", "Approval mail sent (fake log).",
                "token", token
        ));
    }


}


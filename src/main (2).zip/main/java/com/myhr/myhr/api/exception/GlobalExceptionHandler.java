package com.myhr.myhr.api.exception;

import com.myhr.myhr.domain.exception.ApiException;
import com.myhr.myhr.domain.exception.ErrorCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.Instant;
import java.util.Map;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(ApiException.class)
    public ResponseEntity<?> handle(ApiException ex) {
        var code = ex.getCode();
        return ResponseEntity.status(code.status).body(Map.of(
                "timestamp", Instant.now().toString(),
                "error", code.name(),
                "message", code.message
        ));
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<?> handleOther(Exception ex) {
        var code = ErrorCode.INTERNAL_ERROR;
        return ResponseEntity.status(code.status).body(Map.of(
                "timestamp", Instant.now().toString(),
                "error", code.name(),
                "message", code.message
        ));
    }
}

package com.myhr.myhr.domain;

public enum CompanyStatus {
    PENDING, APPROVED, ACTIVE
}
